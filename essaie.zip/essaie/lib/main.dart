
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Contact {
  String nom;
  String prenom;
  String numero;
  String image;

  Contact({required this.nom, required this.prenom, required this.numero, this.image = ''});
}

class ContactProvider extends ChangeNotifier {
  List<Contact> contacts = [];

  void ajouterContact(Contact contact) {
    contacts.add(contact);
    notifyListeners();
  }

  void supprimerContact(Contact contact) {
    contacts.remove(contact);
    notifyListeners();
  }

  void modifierContact(Contact oldContact, Contact newContact) {
    final index = contacts.indexOf(oldContact);
    contacts[index] = newContact;
    notifyListeners();
  }
}

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => ContactProvider(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final TextEditingController searchController = TextEditingController();
  final TextEditingController nomController = TextEditingController();
  final TextEditingController prenomController = TextEditingController();
  final TextEditingController numeroController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gestionnaire de Contacts'),
      ),
      body: Column(
        children: [
          TextField(
            controller: searchController,
            decoration: InputDecoration(
              hintText: 'Rechercher...',
            ),
            onChanged: (query) {
              // Implémentez la logique de recherche ici
            },
          ),
          Expanded(
            child: Consumer<ContactProvider>(
              builder: (context, contactProvider, child) {
                return ListView.builder(
                  itemCount: contactProvider.contacts.length,
                  itemBuilder: (context, index) {
                    final contact = contactProvider.contacts[index];
                    return ListTile(
                      leading: CircleAvatar(
                        //  backgroundImage: contact.image.isNotEmpty
                        //     ? NetworkImage(contact.image)
                        //  : AssetImage('assets/Text.jpg'),
                      ),
                      title: Text('${contact.nom} ${contact.prenom}'),
                      subtitle: Text(contact.numero),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit),
                            onPressed: () {
                              _showEditContactDialog(context, contact);
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.delete),
                            onPressed: () {
                              contactProvider.supprimerContact(contact);
                            },
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddContactDialog(context);
        },
        child: Icon(Icons.add),
      ),
    );
  }

  void _showAddContactDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Ajouter un contact'),
          content: Column(
            children: [
              TextField(
                controller: nomController,
                decoration: InputDecoration(labelText: 'Nom'),
              ),
              TextField(
                controller: prenomController,
                decoration: InputDecoration(labelText: 'Prénom'),
              ),
              TextField(
                controller: numeroController,
                decoration: InputDecoration(labelText: 'Numéro de téléphone'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Annuler'),
            ),
            TextButton(
              onPressed: () {
                final newContact = Contact(
                  nom: nomController.text,
                  prenom: prenomController.text,
                  numero: numeroController.text,
                );
                Provider.of<ContactProvider>(context, listen: false).ajouterContact(newContact);
                Navigator.pop(context);
              },
              child: Text('Enregistrer'),
            ),
          ],
        );
      },
    );
  }

  void _showEditContactDialog(BuildContext context, Contact contact) {
    nomController.text = contact.nom;
    prenomController.text = contact.prenom;
    numeroController.text = contact.numero;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Modifier le contact'),
          content: Column(
            children: [
              TextField(
                controller: nomController,
                decoration: InputDecoration(labelText: 'Nom'),
              ),
              TextField(
                controller: prenomController,
                decoration: InputDecoration(labelText: 'Prénom'),
              ),
              TextField(
                controller: numeroController,
                decoration: InputDecoration(labelText: 'Numéro de téléphone'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Annuler'),
            ),
            TextButton(
              onPressed: () {
                final newContact = Contact(
                  nom: nomController.text,
                  prenom: prenomController.text,
                  numero: numeroController.text,
                );
                Provider.of<ContactProvider>(context, listen: false)
                    .modifierContact(contact, newContact);
                Navigator.pop(context);
              },
              child: Text('Enregistrer'),
            ),
          ],
        );
      },
    );
  }
}