package com.example.essaie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
